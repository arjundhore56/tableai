# TABLEAI V1 — Setup & Launch

## What is already built
- TABLEAI dashboard
- Business profile
- 6 tools: Plan My Week, Create Content, Create Promotion, Reply to Review, Customer Message, Growth Ideas
- Local/browser-saved profile
- Copy output
- Download output as .txt
- Mobile + desktop responsive UI
- No API key required for this demo V1

## Easiest way to put it online
### Option A — Vercel (recommended)
1. Create a GitHub account if you do not have one.
2. Create a new GitHub repository called `tableai`.
3. Upload `index.html` and this README file.
4. Open Vercel and sign in with GitHub.
5. Click Add New Project → import the `tableai` repository.
6. Keep the default settings and deploy.
7. Vercel will give you a temporary public URL.
8. Later, connect your own domain from Vercel Project Settings → Domains.

## Important: this V1 is a front-end prototype
The current generated outputs are built into the browser. It is NOT yet a secure multi-user SaaS and it does not yet contain a real AI API, database, login system or payment gateway.

## What you need to create next
### 1. Supabase
Create a Supabase project for:
- user accounts
- business profiles
- saved outputs
- database

Do not send me your password. You only need to enter your own project settings into the app.

### 2. AI API
Create an API account with your chosen AI provider and create an API key.
NEVER put a secret API key directly inside `index.html` or other browser-side code.
The key must be stored as a server-side environment variable and used through a backend/edge function.

### 3. Payments
For India, choose a payment provider that supports your business/account and current onboarding requirements. Add payment only after the core product works.

## Recommended final architecture
Browser → Vercel → secure server/edge function → AI provider
                       ↓
                    Supabase
                       ↓
                 user + profile + usage

## Your job
1. Put the files online using Vercel.
2. Send me the public TABLEAI URL.
3. I can then help you with the exact next configuration steps for the real AI, Supabase login/database and payments.

## Do not share
- passwords
- API secret keys
- payment account passwords
- recovery codes

Share only public URLs, project IDs, or screenshots when needed.
